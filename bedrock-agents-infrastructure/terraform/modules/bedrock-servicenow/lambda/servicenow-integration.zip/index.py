import json
import os
from datetime import datetime

def lambda_handler(event, context):
    """ServiceNow integration Lambda handler"""
    print(f"Event: {json.dumps(event)}")
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'ServiceNow integration placeholder',
            'timestamp': datetime.utcnow().isoformat()
        })
    }
